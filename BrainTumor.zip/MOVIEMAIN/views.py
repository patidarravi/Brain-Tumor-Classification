from django.shortcuts import render
from django.http import HttpResponse
import cv2
from .models import BrainDLModel
import pydicom as dicom

Output=''
# Create your views here.
def hi(request):
    return render(request, 'hi.html')





def uploadImage(request):
    print("RequestH")
    Pred_Model = BrainDLModel('C:/Users/HP/PycharmProject/MOVIE_A/MOVIEAPP/MOVIEMAIN/vgg16_model.json',
                              'C:/Users/HP/PycharmProject/MOVIE_A/MOVIEAPP/MOVIEMAIN/vgg16_model.hdf5')
    p = request.FILES['image']
    imgsize = (240, 240)
    from .models import User
    filename=str(p)

    user = User(pic=p)
    k=user.pic
    kk=str(k)
    kk.replace(' ','_')
    print(str(k))
    user.save()
    if(kk[-3:] == "dcm"):
        dire = 'C:/Users/HP/PycharmProject/MOVIE_A/MOVIEAPP/media/mriimage/'
        ds = dicom.dcmread(dire+kk)
        pixel_array_numpy = ds.pixel_array
        img = pixel_array_numpy
        cv2.imwrite('C:/Users/HP/PycharmProject/MOVIE_A/MOVIEAPP/media/mriimage/dcm_image.jpg', img)
        kk="dcm_image.jpg"
    else:
        dire = 'C:/Users/HP/PycharmProject/MOVIE_A/MOVIEAPP/media/mriimage/'
        img = cv2.imread(dire+kk)
    img = cv2.resize(
        img,
        dsize=(240,240),
        interpolation=cv2.INTER_CUBIC
    )
    img = img.reshape(-1, 240, 240, 3)
    Output = Pred_Model.predict_tumor(img)
    print(Output)
    print(str(p))
    print(kk)
    dire="/media/mriimage/"
    return render(request, 'hi.html',{'pred':Output,'dire':dire+kk})
