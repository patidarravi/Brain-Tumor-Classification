from django.apps import AppConfig


class MoviemainConfig(AppConfig):
    name = 'MOVIEMAIN'
