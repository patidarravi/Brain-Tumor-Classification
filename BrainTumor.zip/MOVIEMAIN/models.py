from django.db import models

class User(models.Model):
    pic = models.ImageField(upload_to="mriimage")


from keras.models import model_from_json
from keras.utils import CustomObjectScope
from keras.initializers import glorot_uniform
import numpy as np
import tensorflow as tf


class BrainDLModel(object):

    LIST = ["Oh No! Brain Tumor Detected","Congratulations! Tumor is a myth for you"]

    def __init__(self, model_json_file, model_weights_file):
        # load model from JSON file
        with open(model_json_file, "r") as json_file:
            loaded_model_json = json_file.read()
            self.loaded_model = tf.keras.models.model_from_json(loaded_model_json)

        # load weights into the new model
        self.loaded_model.load_weights(model_weights_file)
        self.loaded_model._make_predict_function()

    def predict_tumor(self, img):
        self.preds = self.loaded_model.predict(img)
        print(self.preds)
        print(type(self.preds))
        print(self.preds[0][0])
        if(int(self.preds[0][0])==1):
          return BrainDLModel.LIST[0]
        else:
          return BrainDLModel.LIST[1]