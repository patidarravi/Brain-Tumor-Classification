from django.urls import path,URLPattern
from django.conf.urls import url
from django.views.generic import TemplateView
from . import views



urlpatterns = {
    path('', views.hi, name='home-page'),
    path('upload', views.uploadImage, name='uploadimage'),

}
